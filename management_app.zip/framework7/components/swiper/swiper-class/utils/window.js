export default window;
