export default {
  name: 'contactList',
};
