export default {
  name: 'grid',
};
